package com.example.emotichat

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton

class ProfileActivity : BaseActivity() {

}
